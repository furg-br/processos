# @furg/design-system

Design system canônico da Universidade Federal do Rio Grande, implementado sobre fundamentos do Material Design 3 com APIs próprias e tematização FURG.

## Superfícies públicas

- `@furg/design-system/components`: tipos, contratos e registro tipado de ícones;
- `@furg/design-system/react`: componentes React com JSX semântico;
- `@furg/design-system/web-components`: Custom Elements em light DOM;
- `@furg/design-system/styles/base.css`: tokens e estilos canônicos;
- temas `furg.css` e `vestibular.css`.

## Arquitetura

```text
fundamentos → componentes → blocos → telas → consumidores
                         ↘ representações ↗
```

React e Web Components são implementações paralelas dos mesmos contratos canônicos. Stories da Base usam React como renderer padrão; isso não torna React um adaptador do Storybook nem Web Components um wrapper de React. O Vestibular importa a superfície publicada em `@furg/design-system/react` e mantém API, rotas, sessão e regras de negócio em sua aplicação.

O grafo normativo está em `docs/catalog-architecture.json`. O Storybook apresenta o mapa e a rastreabilidade em `Visão geral/Arquitetura`, e `pnpm check:catalog` impede exports, tags, stories ou dependências órfãs.

Não há dependência de runtime de bibliotecas Material, do runtime visual federal anterior, de fontes de ícones ou de fontes remotas. A família variável Noto Sans é distribuída no próprio pacote. A identidade gov.br permanece somente nos componentes que representam o serviço.

## Tokens

- `--furg-ref-*`: valores de referência;
- `--furg-sys-*`: papéis semânticos de tema;
- `--furg-comp-*`: decisões específicas de componentes.

A tipografia parte de `--furg-ref-font-family-sans` e é aplicada semanticamente por `--furg-sys-font-family`. Consumidores podem substituir o papel de sistema sem alterar os componentes.

Consumidores devem personalizar papéis `--furg-sys-*` e fornecer conteúdo, rotas e assets. Aparência, responsividade, foco e comportamento percebido pertencem ao pacote.

## Uso React

```tsx
import { FurgButton, FurgTextField } from "@furg/design-system/react";
import "@furg/design-system/styles/base.css";
import "@furg/design-system/styles/themes/furg.css";

export function Formulario() {
  return <form><FurgTextField label="Nome" /><FurgButton type="submit">Continuar</FurgButton></form>;
}
```

## Uso Web Components

```ts
import "@furg/design-system/web-components";
```

Valores simples usam atributos. Listas e objetos usam a propriedade `.config`. Eventos `furg-*` têm propagação e atravessam limites de composição.

## Desenvolvimento

```bash
pnpm typecheck
pnpm check:catalog
pnpm build
pnpm lint
pnpm test
pnpm build-storybook
pnpm pack --pack-destination .logs/package
```
