# Changelog

## Não publicado

- substitui a imitação local da barra gov.br pela integração dinâmica oficial da Barra Brasil em React e Web Components;
- adiciona `FurgCarouselSection` para destaques e parceiros, com paridade React/Web Components;
- adiciona o tema `vitrine` e seleção global de temas no Storybook;
- adiciona `FurgShowcaseHero` e `FurgCollaborationSection`, com paridade React/Web Components;
- adiciona a Home de referência em `Projetos/Vitrine de Inovação`.
- consolida títulos de blocos no `FurgSectionHeading`, incluindo o tratamento sobre mídia.
- permite que o tema da Vitrine estenda títulos de seção pela largura do contêiner sem alongar a descrição.
- amplia `FurgAccordion` com conteúdo rico em React e modo de seleção única, mantendo paridade comportamental com Web Components.
- adiciona `FurgCriticalAction` e a variante de botão `danger` para operações destrutivas com justificativa e confirmação digitada.

## 0.4.0 - 2026-07-14

- reconstrói tokens e componentes sobre fundamentos Material 3 com implementação própria;
- entrega APIs públicas `Furg*` para React e Web Components;
- substitui a fonte de ícones anterior por SVGs Material Symbols selecionados e tipados;
- adiciona os temas FURG e Vestibular;
- adota Noto Sans variável, auto-hospedada, como família tipográfica canônica;
- restringe a superfície ao núcleo validado pelo Vestibular;
- adiciona testes de interação, acessibilidade e contratos de pacote.
- incorpora a assinatura oficial gov.br como imagem local nos adaptadores React e Web Components;
- alinha os estados dos cards de ação e adiciona a variante compacta do resumo para conteúdo operacional.
- substitui representações decorativas por QR Codes válidos, com zona de silêncio e paridade React/Web Components.
- torna a arquitetura do catálogo rastreável entre fundamentos, componentes, blocos, telas e representações, com stories React e Web Components completas e validação automatizada contra itens órfãos e ciclos.
