# Avisos de terceiros

Os caminhos SVG selecionados em `src/components/icons.ts` derivam do conjunto Material Symbols/Material Icons mantido pelo Google e distribuído sob a licença Apache 2.0.

Fonte: https://github.com/google/material-design-icons

Licença: https://www.apache.org/licenses/LICENSE-2.0
## Marca gov.br

A assinatura visual gov.br incorporada em `src/components/brand.ts` foi obtida do portal oficial do Governo Federal e deve ser usada sem alterações, conforme o [Manual da Marca gov.br](https://www.gov.br/governodigital/pt-br/legislacao/gov-br/govbr-manualmarca.pdf).

## node-qrcode

A geração das matrizes QR Code usa o pacote [`qrcode`](https://github.com/soldair/node-qrcode), distribuído sob a licença MIT.

## Noto Sans

A família tipográfica Noto Sans é mantida pelo projeto Noto Fonts e distribuída sob a SIL Open Font License 1.1. Os arquivos WOFF2 variáveis incluídos no pacote foram obtidos por meio do pacote [`@fontsource-variable/noto-sans`](https://fontsource.org/fonts/noto-sans).

A licença integral acompanha os arquivos em `dist/styles/fonts/OFL-1.1.txt`.
