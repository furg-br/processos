# @furg/design-system

Design system canônico da Universidade Federal do Rio Grande, implementado sobre fundamentos do Material Design 3 com APIs próprias e tematização FURG.

## Superfícies públicas

- `@furg/design-system/components`: tipos, contratos e registro tipado de ícones;
- `@furg/design-system/react`: componentes React com JSX semântico;
- `@furg/design-system/native`: primeira representação React Native para Android e iOS;
- `@furg/design-system/web-components`: Custom Elements em light DOM;
- `@furg/design-system/styles/base.css`: tokens e estilos canônicos;
- temas `furg.css`, `vestibular.css` e `vitrine.css`.

## Arquitetura

```text
fundamentos → componentes → blocos → telas → consumidores
                         ↘ representações ↗
```

React, React Native e Web Components são implementações paralelas dos contratos canônicos. Stories da Base usam React como renderer padrão; isso não torna uma representação adaptador de outra. A cobertura React Native começa pelas entidades comprovadas pelo App MPU e cresce somente com uso real.

O grafo normativo está em `docs/catalog-architecture.json`. O Storybook apresenta o mapa e a rastreabilidade em `Visão geral/Arquitetura`, e `pnpm check:catalog` impede exports, tags, stories ou dependências órfãs.

`Projetos/Vestibular` e `Projetos/Vitrine de Inovação` reúnem poucos checkpoints de consumidores reais. Essas stories usam apenas a superfície pública do pacote, fixam o tema do projeto e não incorporam API, roteamento, sessão ou regras de negócio.

Não há dependência de runtime de bibliotecas Material, GOVBR-DS ou fontes de ícones. A família variável Noto Sans é distribuída no próprio pacote. `FurgGovBar` delega a barra federal ao script oficial `barra.brasil.gov.br/barra_2.0.js`; os demais componentes não carregam esse serviço.

## Tokens

- `--furg-ref-*`: valores de referência;
- `--furg-sys-*`: papéis semânticos de tema;
- `--furg-comp-*`: decisões específicas de componentes.

A tipografia parte de `--furg-ref-font-family-sans` e é aplicada semanticamente por `--furg-sys-font-family`. Consumidores podem substituir o papel de sistema sem alterar os componentes.

Consumidores devem personalizar papéis `--furg-sys-*` e fornecer conteúdo, rotas e assets. Aparência, responsividade, foco e comportamento percebido pertencem ao pacote.

## Uso React

```tsx
import { FurgButton, FurgTextField } from "@furg/design-system/react";
import "@furg/design-system/styles/base.css";
import "@furg/design-system/styles/themes/furg.css";

export function Formulario() {
  return <form><FurgTextField label="Nome" /><FurgButton type="submit">Continuar</FurgButton></form>;
}
```

O tema é aplicado por `data-furg-theme="furg"`, `data-furg-theme="vestibular"` ou `data-furg-theme="vitrine"` em um ancestral da interface. `FurgAppShell` só fixa o atributo quando a propriedade `theme` é fornecida explicitamente.

## Uso Web Components

```ts
import "@furg/design-system/web-components";
```

Valores simples usam atributos. Listas e objetos usam a propriedade `.config`. Eventos `furg-*` têm propagação e atravessam limites de composição.

## Uso React Native

```tsx
import { FurgButton, FurgMessage, FurgSurface } from "@furg/design-system/native";

export function Registro() {
  return (
    <FurgSurface>
      <FurgMessage title="Pronto para leitura" message="Aponte a câmera para a credencial." />
      <FurgButton onPress={() => undefined}>Simular leitura</FurgButton>
    </FurgSurface>
  );
}
```

O primeiro núcleo inclui botão, campo de texto, mensagem, progresso, chip, superfície e tokens FURG tipados. O consumidor continua responsável por áreas seguras, navegação, câmera, persistência e negócio. A fonte móvel ainda usa a família do sistema enquanto os assets Noto Sans nativos não forem distribuídos pelo pacote.

## Desenvolvimento

```bash
pnpm typecheck
pnpm check:catalog
pnpm build
pnpm lint
pnpm test
pnpm build-storybook
pnpm pack --pack-destination .logs/package
```
